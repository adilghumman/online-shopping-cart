import React from 'react'

const Cancel = () => {
  return (
    <div className='my-24 flex items-center justify-center'>
      <h2 className='text-red-500 text-2xl'>Order Cancel.</h2>
    </div>
  )
}

export default Cancel
